package com.example.akshay.inclass09;

/* Name: Akshay Karai, Naga Poorna Pujitha
   Assignment: InClass 09
   Group: 34
 */

import android.graphics.Color;
import android.location.Address;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.gson.Gson;
import com.google.android.gms.maps.UiSettings;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity  implements OnMapReadyCallback {

    public GoogleMap mMap;
    ArrayList<Response> addressList=null;
    List<LatLng>  locations;
    private UiSettings mUiSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Path Activity");

        SupportMapFragment mapFragment =
                (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        InputStream is = getResources().openRawResource(R.raw.trip);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        String jsonString = writer.toString();
        Gson gson = new Gson();
        Response response = gson.fromJson(jsonString,Response.class);
        Log.d("demo",response.toString());

        locations= new ArrayList<>();

        for(int i =0;i<response.points.length;i++) {
            LatLng latLng = new LatLng(Double.parseDouble(response.getLatitude(i)) , Double.parseDouble(response.getLongitude(i)));
            locations.add(latLng);
        }

        Log.d("demo", locations.toString());

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng start = locations.get(0);
        mUiSettings = mMap.getUiSettings();
        googleMap.addMarker(new MarkerOptions().position(start)).setTitle("Start Location");

        LatLng end = locations.get(locations.size()-1);
        googleMap.addMarker(new MarkerOptions().position(end)).setTitle("End Location");

        PolylineOptions polylineOptions = new PolylineOptions();
        polylineOptions.addAll(locations);
        polylineOptions
                .width(5)
                .color(Color.RED);

        final Polyline trackerLine = mMap.addPolyline(polylineOptions);

        mMap.setOnMapLoadedCallback(new GoogleMap.OnMapLoadedCallback() {
            @Override
            public void onMapLoaded() {
                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                for(int i = 0; i < trackerLine.getPoints().size();i++){
                    builder.include(trackerLine.getPoints().get(i));
                }
                LatLngBounds bounds = builder.build();
                int padding = 100;
                CameraUpdate cu2 = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                mMap.animateCamera(cu2);
                mUiSettings.setZoomControlsEnabled(true);
            }
        });
    }

    private boolean checkReady() {
        if (mMap == null) {
            Toast.makeText(this, "map_not_ready", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
    public void setZoomButtonsEnabled(View v) {
        if (!checkReady()) {
            return;
        }
    }
}




