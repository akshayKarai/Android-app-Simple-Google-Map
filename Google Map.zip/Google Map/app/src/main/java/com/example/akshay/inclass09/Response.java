package com.example.akshay.inclass09;

import com.google.gson.annotations.SerializedName;

import java.util.Arrays;

/**
 * Created by akshay on 3/26/18.
 */

/* Name: Akshay Karai, Naga Poorna Pujitha
   Assignment: InClass 09
   Group: 34
 */

public class Response {

    @Override
    public String toString() {
        return "Response{" +
                "points=" + Arrays.toString(points) +
                '}';
    }

    @SerializedName("points")
    public Points[] points;

    public static class Points {
        @Override
        public String toString() {
            return "Points{" +
                    "latitude='" + latitude + '\'' +
                    ", longitude='" + longitude + '\'' +
                    '}';
        }

        @SerializedName("latitude")
        public String latitude;

        @SerializedName("longitude")
        public String longitude;
    }

    public String getLatitude(int index){
        return points[index].latitude;
    }

    public String getLongitude(int index){
        return points[index].longitude;
    }
}
